#include "cmMod.hpp"

#include <cstdlib>

int main() {
  CmMod cc;
  cc.asyncIncrement();
  return cc.getNum() == 1 ? EXIT_SUCCESS : EXIT_FAILURE;
}

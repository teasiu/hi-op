#include "libB.hpp"

std::string getZlibVers(void) {
  return "STUB";
}

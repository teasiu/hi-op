#include <iostream>
#include <fstream>

using namespace std;

int main(int argc, const char *argv[]) {
  if(argc < 2) {
    cerr << argv[0] << " requires an output file!" << endl;
    return 1;
  }
  ofstream out(argv[1]);
  out << R"(
#include "test.hpp"

std::string getStr() {
  return "Hello World";
}
)";

  return 0;
}

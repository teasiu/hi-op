#include<mylib.h>

int main(void) {
    return func1() - func2();
}

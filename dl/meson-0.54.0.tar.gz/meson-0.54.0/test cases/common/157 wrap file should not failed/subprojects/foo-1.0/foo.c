int dummy_func(void) {
    return 42;
}

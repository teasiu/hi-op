#include<config2.h>

int main(void) {
    return ZERO_RESULT;
}

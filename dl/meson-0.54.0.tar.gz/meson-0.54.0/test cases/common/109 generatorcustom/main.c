#include<stdio.h>

#include"alltogether.h"

int main(void) {
    return 0;
}

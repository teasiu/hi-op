// Package crypto provides common crypto libraries for Xray.
package crypto // import "github.com/xtls/xray-core/common/crypto"

//go:generate go run github.com/xtls/xray-core/common/errors/errorgen

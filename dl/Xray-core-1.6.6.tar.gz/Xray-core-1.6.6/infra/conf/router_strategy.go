package conf

const (
	strategyRandom    string = "random"
	strategyLeastPing string = "leastping"
)
